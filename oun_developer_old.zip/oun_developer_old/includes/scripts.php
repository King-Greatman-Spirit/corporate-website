

<!-- jquery plugins -->
<script src="assests/js/vendor/bootstrap.bundle.min.js"></script>
<script src="assests/js/vendor/jquery.min.js"></script>
<script src="assests/js/vendor/swiper-bundle.min.js"></script>
<script src="assests/js/script.js"></script>
<script src="assests/js/swiper-script.js"></script>
<script src="assests/js/submit-form.js"></script>
<script src="assests/js/vendor/isotope.pkgd.min.js"></script>
<script src="assests/js/vendor/fslightbox.js"></script>

</body>

</html>
