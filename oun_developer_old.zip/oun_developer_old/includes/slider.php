
<section class="section image-infinite-bg position-relative"
    style="background-size: cover; background-position: center ;padding: 15em 1em 15em 1em;"
    data-images='["assests/image/image-1920x900-1.jpg", "assests/image/image-1920x900-2.jpg"]'>
    <div class="r-container h-100">
        <div class="image-overlay"></div>
        <div class="d-flex flex-column justify-content-center align-items-center text-center gap-3 h-100 position-relative"
            style="z-index: 2;">
            <h2 class="text-title font-1 lh-1 accent-color">INNOVATIVE CONCEPTS</h2>
            <h2 class="text-title text-white font-1 lh-1 mt-4">FOR YOUR DESIGN</h2>

            <!-- <div class="d-flex flex-row gap-3">
                <a type="button" href="project"
                    class="btn bg-transparent button-outline-white rounded-0 font-1">OUR PROJECT</a>
                <a type="button" href="events"
                    class="btn bg-transparent button-outline-accent rounded-0 font-1">OUR EVENTS</a>
            </div> -->
        </div>
    </div>
</section>