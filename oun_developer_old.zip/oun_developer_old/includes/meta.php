<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>OUN Developers</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="assests/image/oun_img/fav.ico">

    <!-- Stylesheet -->
    <link href="assests/css/vendor/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assests/css/vendor/fontawesome.css">
    <link rel="stylesheet" href="assests/css/vendor/brands.css">
    <link rel="stylesheet" href="assests/css/vendor/regular.css">
    <link rel="stylesheet" href="assests/css/vendor/solid.css">
    <link rel="stylesheet" href="assests/css/vendor/swiper-bundle.min.css">
    <link rel="stylesheet" href="assests/css/style.css">

    
</head>

<body id="top">
    